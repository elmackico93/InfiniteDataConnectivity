
# Maskra – Creazione di Avatar 3D e Analisi delle Espressioni

![Maskra Logo](assets/img/repo-logo.png)

## Descrizione
Maskra è un’app innovativa che unisce tecnologie avanzate di riconoscimento facciale e intelligenza artificiale
per permettere agli utenti di creare avatar 3D personalizzati e realistici. Progettata per migliorare la 
comunicazione online, Maskra offre funzioni di analisi delle espressioni facciali, personalizzazione avanzata 
e integrazione con piattaforme di videoconferenza, garantendo al contempo privacy e sicurezza.

Grazie all’utilizzo di CoreML per il riconoscimento delle caratteristiche facciali e a un motore di rendering 
basato su SceneKit, Maskra genera modelli 3D dettagliati e di grande impatto visivo.

### Funzionalità Principali
- **Creazione di avatar 3D realistici**: Basati sui tratti facciali dell'utente, con un risultato accurato e visivamente accattivante.
- **Analisi delle espressioni**: Fornisce suggerimenti su come migliorare la percezione sociale e professionale.
- **Personalizzazione avanzata**: Filtri, stili e opzioni per adattare gli avatar a contesti diversi.
- **Filtro per videochiamate**: Usa il tuo avatar in videoconferenze su Zoom, Teams, Meet, ecc.
- **Marketplace**: Scopri, crea e condividi avatar con la community, per un tocco di creatività in più.

---

## Screenshot
![Screenshot 1](assets/img/image.png)
![Screenshot 2](assets/img/image1.png)
![Screenshot 3](assets/img/0009C770-F4AE-421B-BE8B-F21DC1F699A1.png)

---

## Configurazione del Progetto

1. **File di Configurazione**:
   - `config.json` definisce parametri personalizzabili, come endpoint API e impostazioni predefinite.

2. **Chiavi API**:
   - Registra il progetto su Maskra Dev Console (link da definire) per ottenere le chiavi API necessarie.

3. **Ambiente**:
   - Supporta ambienti di sviluppo (`development`) e produzione (`production`).

---
